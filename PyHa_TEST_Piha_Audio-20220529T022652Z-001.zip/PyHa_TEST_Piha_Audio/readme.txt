All relevant audio from the PyHa tutorial can be found within the "TEST" folder.
In order to replicate the results displayed on the github repository, make sure
the wav file audio clips are located in a folder called "TEST" in the same directory
path as we had in the Jupyter Notebook tutorial.

All audio clips could be found on xeno-canto.org under the Creative Commons 
Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) 
https://creativecommons.org/licenses/by-nc-sa/4.0/ license

The manual labels for this dataset as of this time are automatically installed when
the repository is cloned. We also provide an extra copy in this directory.